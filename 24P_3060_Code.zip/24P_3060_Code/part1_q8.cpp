#include <chrono>
#include <iostream>
#include <mutex>
#include <random>
#include <thread>
#include <vector>
using namespace std;

int availableTickets = 12;
mutex ticketMutex;
mutex coutMutex;

void reserveTicket(int userId) {
    mt19937 gen(random_device{}() + userId);
    uniform_int_distribution<int> delay(40, 120);

    while (true) {
        int ticketNumber = -1;
        {
            lock_guard<mutex> lock(ticketMutex);
            if (availableTickets > 0) {
                ticketNumber = availableTickets;
                --availableTickets;
            } else {
                lock_guard<mutex> out(coutMutex);
                cout << "User " << userId << ": no tickets left.\n";
                break;
            }
        }

        {
            lock_guard<mutex> out(coutMutex);
            cout << "User " << userId << " reserved ticket #" << ticketNumber
                 << ". Remaining = " << availableTickets << '\n';
        }
        this_thread::sleep_for(chrono::milliseconds(delay(gen)));
    }
}

int main() {
    const int users = 6;
    vector<thread> threads;
    for (int i = 1; i <= users; ++i) {
        threads.emplace_back(reserveTicket, i);
    }
    for (auto &t : threads) t.join();
    cout << "Reservation system closed. Final tickets = " << availableTickets << '\n';
    return 0;
}
