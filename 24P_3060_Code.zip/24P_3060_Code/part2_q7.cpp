#include <iomanip>
#include <iostream>
#include <limits>
#include <string>
#include <vector>
using namespace std;

using Matrix = vector<vector<int>>;
using Vector = vector<int>;

void printVector(const string &name, const Vector &v) {
    cout << name << " = [ ";
    for (int x : v) cout << x << ' ';
    cout << "]\n";
}

void printMatrix(const string &name, const Matrix &m) {
    cout << name << ":\n";
    for (size_t i = 0; i < m.size(); ++i) {
        cout << "P" << i << ": ";
        for (int x : m[i]) cout << setw(4) << x;
        cout << '\n';
    }
}

Matrix calculateNeed(const Matrix &maximum, const Matrix &allocation) {
    int p = maximum.size();
    int r = maximum[0].size();
    Matrix need(p, Vector(r, 0));
    for (int i = 0; i < p; ++i) {
        for (int j = 0; j < r; ++j) {
            need[i][j] = maximum[i][j] - allocation[i][j];
        }
    }
    return need;
}

bool lessOrEqual(const Vector &a, const Vector &b) {
    for (size_t i = 0; i < a.size(); ++i) {
        if (a[i] > b[i]) return false;
    }
    return true;
}

bool isSafe(const Matrix &allocation, const Matrix &maximum, const Vector &available,
            Vector &safeSequence, bool verbose = true) {
    int p = allocation.size();
    int r = available.size();
    Matrix need = calculateNeed(maximum, allocation);
    Vector work = available;
    vector<bool> finish(p, false);
    safeSequence.clear();

    if (verbose) {
        cout << "\n--- Safety Algorithm Log ---\n";
        printMatrix("Need", need);
        printVector("Initial Work", work);
    }

    int completed = 0;
    while (completed < p) {
        bool found = false;
        for (int i = 0; i < p; ++i) {
            if (!finish[i] && lessOrEqual(need[i], work)) {
                if (verbose) {
                    cout << "Select P" << i << " because Need[P" << i << "] <= Work.\n";
                }
                for (int j = 0; j < r; ++j) work[j] += allocation[i][j];
                finish[i] = true;
                safeSequence.push_back(i);
                ++completed;
                found = true;
                if (verbose) {
                    printVector("Updated Work", work);
                    cout << "Finish[P" << i << "] = true\n";
                }
            }
        }
        if (!found) {
            if (verbose) cout << "No unfinished process can be satisfied. State is unsafe.\n";
            return false;
        }
    }
    if (verbose) {
        cout << "System is SAFE. Safe sequence: ";
        for (int id : safeSequence) cout << "P" << id << ' ';
        cout << "\n";
    }
    return true;
}

bool requestResources(int pid, const Vector &request, Matrix &allocation,
                      Matrix &maximum, Vector &available) {
    int r = available.size();
    Matrix need = calculateNeed(maximum, allocation);

    cout << "\n--- Request by P" << pid << " ---\n";
    printVector("Request", request);

    if (pid < 0 || pid >= (int)allocation.size()) {
        cout << "Denied: invalid process number.\n";
        return false;
    }
    if (!lessOrEqual(request, need[pid])) {
        cout << "Denied: request exceeds the remaining need of P" << pid << ".\n";
        return false;
    }
    if (!lessOrEqual(request, available)) {
        cout << "Denied: resources are not currently available.\n";
        return false;
    }

    for (int j = 0; j < r; ++j) {
        available[j] -= request[j];
        allocation[pid][j] += request[j];
    }

    Vector safeSequence;
    if (isSafe(allocation, maximum, available, safeSequence, true)) {
        cout << "Request GRANTED.\n";
        return true;
    }

    for (int j = 0; j < r; ++j) {
        available[j] += request[j];
        allocation[pid][j] -= request[j];
    }
    cout << "Request DENIED and rolled back because it makes the state unsafe.\n";
    return false;
}

int readNonNegative(const string &prompt) {
    int value;
    while (true) {
        cout << prompt;
        if (cin >> value && value >= 0) return value;
        cout << "Invalid input. Enter a non-negative integer.\n";
        cin.clear();
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
    }
}

Matrix readMatrix(const string &name, int p, int r) {
    Matrix m(p, Vector(r));
    cout << "Enter " << name << " matrix (" << p << " x " << r << "):\n";
    for (int i = 0; i < p; ++i) {
        cout << "P" << i << ": ";
        for (int j = 0; j < r; ++j) cin >> m[i][j];
    }
    return m;
}

int main() {
    cout << "Banker's Algorithm - Dynamic Requests and Multiple Test Cases\n";
    char again = 'y';
    while (again == 'y' || again == 'Y') {
        int p = readNonNegative("Number of processes: ");
        int r = readNonNegative("Number of resource types: ");
        if (p == 0 || r == 0) {
            cout << "Both values must be greater than zero.\n";
            continue;
        }

        Matrix allocation = readMatrix("Allocation", p, r);
        Matrix maximum = readMatrix("Maximum", p, r);
        Vector available(r);
        cout << "Enter Available vector: ";
        for (int j = 0; j < r; ++j) cin >> available[j];

        Vector safeSequence;
        isSafe(allocation, maximum, available, safeSequence, true);

        char reqAgain = 'y';
        while (reqAgain == 'y' || reqAgain == 'Y') {
            int pid;
            cout << "\nEnter process number for request: ";
            cin >> pid;
            Vector request(r);
            cout << "Enter request vector: ";
            for (int j = 0; j < r; ++j) cin >> request[j];
            requestResources(pid, request, allocation, maximum, available);
            cout << "Another request for this test case? (y/n): ";
            cin >> reqAgain;
        }

        cout << "Run another test case? (y/n): ";
        cin >> again;
    }
    cout << "Program ended safely.\n";
    return 0;
}
