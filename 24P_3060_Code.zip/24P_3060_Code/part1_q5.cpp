#include <atomic>
#include <chrono>
#include <iostream>
#include <mutex>
#include <thread>
#include <vector>
using namespace std;

class BoundedTASLock {
private:
    atomic<bool> lockFlag;
    vector<atomic<bool>> waiting;
    int n;

    bool test_and_set() {
        // Returns the old value and sets the flag to true atomically.
        return lockFlag.exchange(true, memory_order_acquire);
    }

public:
    explicit BoundedTASLock(int processCount) : lockFlag(false), waiting(processCount), n(processCount) {
        for (int i = 0; i < n; ++i) waiting[i].store(false);
    }

    void lock(int i) {
        waiting[i].store(true, memory_order_release);
        bool key = true;
        while (waiting[i].load(memory_order_acquire) && key) {
            key = test_and_set();
            if (key) this_thread::yield();
        }
        waiting[i].store(false, memory_order_release);
    }

    void unlock(int i) {
        int j = (i + 1) % n;
        while (j != i && !waiting[j].load(memory_order_acquire)) {
            j = (j + 1) % n;
        }
        if (j == i) {
            lockFlag.store(false, memory_order_release);
        } else {
            // Directly pass permission to the next waiting process.
            waiting[j].store(false, memory_order_release);
        }
    }
};

mutex coutMutex;
int sharedCounter = 0;

void processWork(int id, BoundedTASLock &tasLock, int iterations) {
    for (int round = 1; round <= iterations; ++round) {
        tasLock.lock(id);
        int before = sharedCounter;
        this_thread::sleep_for(chrono::milliseconds(30));
        ++sharedCounter;
        {
            lock_guard<mutex> out(coutMutex);
            cout << "P" << id << " in critical section, round " << round
                 << ", counter " << before << " -> " << sharedCounter << '\n';
        }
        tasLock.unlock(id);
        this_thread::sleep_for(chrono::milliseconds(20));
    }
}

int main() {
    int n = 5;
    int iterations = 3;
    BoundedTASLock tasLock(n);
    vector<thread> processes;

    for (int i = 0; i < n; ++i) {
        processes.emplace_back(processWork, i, ref(tasLock), iterations);
    }
    for (auto &t : processes) t.join();

    cout << "Final counter value = " << sharedCounter << '\n';
    return 0;
}
