#include <chrono>
#include <condition_variable>
#include <deque>
#include <iostream>
#include <mutex>
#include <random>
#include <thread>
#include <vector>
using namespace std;

enum class State { THINKING, HUNGRY, EATING };

class DiningMonitor {
private:
    int n;
    int eatingCount;
    vector<State> state;
    deque<int> fifoQueue;
    mutex mtx;
    vector<condition_variable> cv;

    int left(int i) const { return (i + n - 1) % n; }
    int right(int i) const { return (i + 1) % n; }

    bool canEat(int i) const {
        return !fifoQueue.empty() && fifoQueue.front() == i &&
               eatingCount < 3 &&
               state[left(i)] != State::EATING &&
               state[right(i)] != State::EATING;
    }

public:
    explicit DiningMonitor(int count)
        : n(count), eatingCount(0), state(count, State::THINKING), cv(count) {}

    void pickupForks(int i) {
        unique_lock<mutex> lock(mtx);
        state[i] = State::HUNGRY;
        fifoQueue.push_back(i);
        cout << "Philosopher " << i << " is hungry.\n";

        cv[i].wait(lock, [&] { return canEat(i); });
        fifoQueue.pop_front();
        state[i] = State::EATING;
        ++eatingCount;
        cout << "Philosopher " << i << " starts eating. Eaters = " << eatingCount << '\n';

        for (auto &condition : cv) condition.notify_all();
    }

    void putdownForks(int i) {
        unique_lock<mutex> lock(mtx);
        state[i] = State::THINKING;
        --eatingCount;
        cout << "Philosopher " << i << " stops eating. Eaters = " << eatingCount << '\n';
        for (auto &condition : cv) condition.notify_all();
    }
};

void philosopher(int id, DiningMonitor &monitor, int meals) {
    mt19937 gen(random_device{}() + id);
    uniform_int_distribution<int> pause(80, 180);

    for (int meal = 1; meal <= meals; ++meal) {
        cout << "Philosopher " << id << " is thinking.\n";
        this_thread::sleep_for(chrono::milliseconds(pause(gen)));
        monitor.pickupForks(id);
        this_thread::sleep_for(chrono::milliseconds(pause(gen)));
        monitor.putdownForks(id);
    }
}

int main() {
    const int philosophers = 5;
    const int mealsEach = 3;
    DiningMonitor monitor(philosophers);
    vector<thread> threads;

    for (int i = 0; i < philosophers; ++i) {
        threads.emplace_back(philosopher, i, ref(monitor), mealsEach);
    }
    for (auto &t : threads) t.join();

    cout << "All philosophers ate without deadlock or starvation.\n";
    return 0;
}
