#include <atomic>
#include <chrono>
#include <iostream>
#include <mutex>
#include <random>
#include <thread>
using namespace std;

atomic<bool> flag[2];
atomic<int> turn;
int sum = 0;
mutex coutMutex;

void enterRegion(int i) {
    int j = 1 - i;
    flag[i].store(true);
    turn.store(j);
    while (flag[j].load() && turn.load() == j) {
        this_thread::yield();
    }
}

void leaveRegion(int i) {
    flag[i].store(false);
}

void worker(int id) {
    mt19937 gen(random_device{}() + id);
    uniform_int_distribution<int> subtractValue(1, 3);

    for (int k = 1; k <= 10; ++k) {
        enterRegion(id);
        int before = sum;
        sum += 5;
        {
            lock_guard<mutex> out(coutMutex);
            cout << "Thread " << id << " adds 5: " << before << " -> " << sum << '\n';
        }
        leaveRegion(id);
        this_thread::sleep_for(chrono::milliseconds(20));
    }

    int r = subtractValue(gen);
    enterRegion(id);
    int before = sum;
    sum -= r;
    {
        lock_guard<mutex> out(coutMutex);
        cout << "Thread " << id << " subtracts " << r << ": " << before << " -> " << sum << '\n';
    }
    leaveRegion(id);
}

int main() {
    flag[0].store(false);
    flag[1].store(false);
    turn.store(0);

    thread t0(worker, 0);
    thread t1(worker, 1);
    t0.join();
    t1.join();

    cout << "Final value of sum = " << sum << '\n';
    return 0;
}
