#include <chrono>
#include <iostream>
#include <mutex>
#include <queue>
#include <random>
#include <semaphore.h>
#include <thread>
#include <vector>
using namespace std;

const int BUFFER_SIZE = 10;
queue<int> bufferQueue;
sem_t emptySlots;
sem_t fullSlots;
mutex bufferMutex;
mutex coutMutex;

void producer(int id) {
    mt19937 gen(random_device{}() + id);
    uniform_int_distribution<int> itemDist(1, 99);
    uniform_int_distribution<int> pause(100, 300);

    while (true) {
        int item = itemDist(gen);
        sem_wait(&emptySlots);
        {
            lock_guard<mutex> lock(bufferMutex);
            bufferQueue.push(item);
            lock_guard<mutex> out(coutMutex);
            cout << "Producer " << id << " produced: " << item
                 << " | Buffer size = " << bufferQueue.size() << '\n';
        }
        sem_post(&fullSlots);
        this_thread::sleep_for(chrono::milliseconds(pause(gen)));
    }
}

void consumer(int id) {
    mt19937 gen(random_device{}() + 100 + id);
    uniform_int_distribution<int> pause(150, 350);

    while (true) {
        sem_wait(&fullSlots);
        int item;
        {
            lock_guard<mutex> lock(bufferMutex);
            item = bufferQueue.front();
            bufferQueue.pop();
            lock_guard<mutex> out(coutMutex);
            cout << "Consumer " << id << " consumed: " << item
                 << " | Buffer size = " << bufferQueue.size() << '\n';
        }
        sem_post(&emptySlots);
        this_thread::sleep_for(chrono::milliseconds(pause(gen)));
    }
}

int main() {
    int producers = 3, consumers = 2;
    sem_init(&emptySlots, 0, BUFFER_SIZE);
    sem_init(&fullSlots, 0, 0);

    vector<thread> threads;
    for (int i = 0; i < producers; ++i) threads.emplace_back(producer, i);
    for (int i = 0; i < consumers; ++i) threads.emplace_back(consumer, i);

    for (auto &t : threads) t.join();

    sem_destroy(&emptySlots);
    sem_destroy(&fullSlots);
    return 0;
}
