#include <chrono>
#include <iostream>
#include <semaphore.h>
#include <thread>
using namespace std;

sem_t memoryMutex;
sem_t startA, startB;
sem_t aDone, bDone;

int sharedMemory = 100;
const int CYCLES = 5;

void processA() {
    for (int cycle = 1; cycle <= CYCLES; ++cycle) {
        sem_wait(&startA);
        sem_wait(&memoryMutex);
        cout << "Cycle " << cycle << ": Process A reads sharedMemory = " << sharedMemory << '\n';
        sem_post(&memoryMutex);
        sem_post(&aDone);
        this_thread::sleep_for(chrono::milliseconds(70));
    }
}

void processB() {
    for (int cycle = 1; cycle <= CYCLES; ++cycle) {
        sem_wait(&startB);
        sem_wait(&memoryMutex);
        sharedMemory += 10;
        cout << "Cycle " << cycle << ": Process B writes sharedMemory = " << sharedMemory << '\n';
        sem_post(&memoryMutex);
        sem_post(&bDone);
        this_thread::sleep_for(chrono::milliseconds(90));
    }
}

void processC() {
    for (int cycle = 1; cycle <= CYCLES; ++cycle) {
        sem_wait(&aDone);
        sem_wait(&bDone);
        sem_wait(&memoryMutex);
        cout << "Cycle " << cycle << ": Process C proceeds after A and B. Value = "
             << sharedMemory << "\n\n";
        sem_post(&memoryMutex);
        sem_post(&startA);
        sem_post(&startB);
    }
}

int main() {
    sem_init(&memoryMutex, 0, 1);
    sem_init(&startA, 0, 1);
    sem_init(&startB, 0, 1);
    sem_init(&aDone, 0, 0);
    sem_init(&bDone, 0, 0);

    thread a(processA), b(processB), c(processC);
    a.join();
    b.join();
    c.join();

    sem_destroy(&memoryMutex);
    sem_destroy(&startA);
    sem_destroy(&startB);
    sem_destroy(&aDone);
    sem_destroy(&bDone);
    return 0;
}
